package com.Project.RentalMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentalMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
