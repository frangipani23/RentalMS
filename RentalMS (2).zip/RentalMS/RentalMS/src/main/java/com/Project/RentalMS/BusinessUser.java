package com.Project.RentalMS;
import jakarta.persistence.*;
import jakarta.validation.constraints.Email;

@Entity
@Table(name = "business_users")
public class BusinessUser {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "first_name", nullable = false)
    private String firstName;

    @Email
    @Column(name = "last_name", nullable = false)
    private String lastName;

    @Column(name = "email", nullable = false, unique = true)
    private String email;

    @Column(name = "mobile_number", nullable = false)
    private String mobileNumber;

    @Column(name = "business_name", nullable = false)
    private String businessName;

    @Column(name = "password", nullable = false)
    private String password;

    @Column(name = "address", nullable = false)
    private String address;

    // Equipment No.1
    @Column(name = "equipment_1_name")
    private String equipment1Name;

    @Column(name = "equipment_1_quantity")
    private Integer equipment1Quantity;

    @Column(name = "equipment_1_price")
    private Double equipment1Price;

    // Equipment No.2
    @Column(name = "equipment_2_name")
    private String equipment2Name;

    @Column(name = "equipment_2_quantity")
    private Integer equipment2Quantity;

    @Column(name = "equipment_2_price")
    private Double equipment2Price;

    // Equipment No.3
    @Column(name = "equipment_3_name")
    private String equipment3Name;

    @Column(name = "equipment_3_quantity")
    private Integer equipment3Quantity;

    @Column(name = "equipment_3_price")
    private Double equipment3Price;

    // Getters and Setters
    // Getters
    public Long getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmail() {
        return email;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public String getBusinessName() {
        return businessName;
    }

    public String getPassword() {
        return password;
    }

    public String getAddress() {
        return address;
    }

   

    // Setters
    public void setId(Long id) {
        this.id = id;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    

    // Constructor(s)
     // No-argument constructor
     public BusinessUser() {
    }

    // All-arguments constructor
    public BusinessUser(String firstName, String lastName, String email, String mobileNumber, String businessName, String password, String address) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.mobileNumber = mobileNumber;
        this.businessName = businessName;
        this.password = password;
        this.address = address;
        
    }
}

