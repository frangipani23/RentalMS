package com.Project.RentalMS;

import jakarta.persistence.*;

@Entity
@Table(name = "bookings")
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long bookingId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "business_user_id", nullable = false)
    private BusinessUser businessUser;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "equipment_id", nullable = false)
    private Equipment equipment;

    @Column(name = "equipment_quantity", nullable = false)
    private Integer equipmentQuantity;

    @Column(name = "total_price", nullable = false)
    private Double totalPrice;

    // No-argument constructor
    public Booking() {
    }

    // All-arguments constructor
    public Booking(Customer customer, BusinessUser businessUser, Equipment equipment, Integer equipmentQuantity, Double totalPrice) {
        this.customer = customer;
        this.businessUser = businessUser;
        this.equipment = equipment;
        this.equipmentQuantity = equipmentQuantity;
        this.totalPrice = totalPrice;
    }

    // Getters
    public Long getBookingId() {
        return bookingId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public BusinessUser getBusinessUser() {
        return businessUser;
    }

    public Equipment getEquipment() {
        return equipment;
    }

    public Integer getEquipmentQuantity() {
        return equipmentQuantity;
    }

    public Double getTotalPrice() {
        return totalPrice;
    }

    // Setters
    public void setBookingId(Long bookingId) {
        this.bookingId = bookingId;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public void setBusinessUser(BusinessUser businessUser) {
        this.businessUser = businessUser;
    }

    public void setEquipment(Equipment equipment) {
        this.equipment = equipment;
    }

    public void setEquipmentQuantity(Integer equipmentQuantity) {
        this.equipmentQuantity = equipmentQuantity;
    }

    public void setTotalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
    }
}
