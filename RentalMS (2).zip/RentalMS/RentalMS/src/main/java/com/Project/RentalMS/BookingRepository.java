package com.Project.RentalMS;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {
    // Custom query methods (if needed)

    List<Booking> findByCustomer(Customer customer);

    // Find Bookings by BusinessUser
    List<Booking> findByBusinessUser(BusinessUser businessUser);

    // Find Bookings by Equipment
    List<Booking> findByEquipment(Equipment equipment);
}
