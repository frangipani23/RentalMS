package com.Project.RentalMS;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BusinessUserRepository extends JpaRepository<BusinessUser, Long> {
    // Custom query methods (if needed)
        // Find by Email
    Optional<BusinessUser> findByEmail(String email);

    // Custom query to find BusinessUsers by BusinessName
    List<BusinessUser> findByBusinessName(String businessName);
}
