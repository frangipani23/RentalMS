package com.Project.RentalMS;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {
    // Custom query methods (if needed)
        // Find by Email
    Optional<Customer> findByEmail(String email);

    // Custom query to find Customers by Name
    List<Customer> findByName(String name);
}
