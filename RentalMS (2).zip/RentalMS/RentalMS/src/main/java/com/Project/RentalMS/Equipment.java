package com.Project.RentalMS;
import jakarta.persistence.*;

@Entity
@Table(name = "equipment")
public class Equipment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name")
    private String equipment1Name;

    @Column(name = "quantity")
    private Integer equipment1Quantity;

    @Column(name = "price")
    private Double equipment1Price;

        @Column(name = "name")
    private String equipment2Name;

    @Column(name = "quantity")
    private Integer equipment2Quantity;

    @Column(name = "price")
    private Double equipment2Price;

        @Column(name = "name")
    private String equipment3Name;

    @Column(name = "quantity")
    private Integer equipment3Quantity;

    @Column(name = "price")
    private Double equipment3Price;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "business_user_id", nullable = false)
    private BusinessUser businessUser;

    // Constructors, getters, setters
     public String getEquipment1Name() {
        return equipment1Name;
    }

    public Integer getEquipment1Quantity() {
        return equipment1Quantity;
    }

    public Double getEquipment1Price() {
        return equipment1Price;
    }

    public String getEquipment2Name() {
        return equipment2Name;
    }

    public Integer getEquipment2Quantity() {
        return equipment2Quantity;
    }

    public Double getEquipment2Price() {
        return equipment2Price;
    }

    public String getEquipment3Name() {
        return equipment3Name;
    }

    public Integer getEquipment3Quantity() {
        return equipment3Quantity;
    }

    public Double getEquipment3Price() {
        return equipment3Price;
    }

    public void setEquipment1Name(String equipment1Name) {
        this.equipment1Name = equipment1Name;
    }

    public void setEquipment1Quantity(Integer equipment1Quantity) {
        this.equipment1Quantity = equipment1Quantity;
    }

    public void setEquipment1Price(Double equipment1Price) {
        this.equipment1Price = equipment1Price;
    }

    public void setEquipment2Name(String equipment2Name) {
        this.equipment2Name = equipment2Name;
    }

    public void setEquipment2Quantity(Integer equipment2Quantity) {
        this.equipment2Quantity = equipment2Quantity;
    }

    public void setEquipment2Price(Double equipment2Price) {
        this.equipment2Price = equipment2Price;
    }

    public void setEquipment3Name(String equipment3Name) {
        this.equipment3Name = equipment3Name;
    }

    public void setEquipment3Quantity(Integer equipment3Quantity) {
        this.equipment3Quantity = equipment3Quantity;
    }
        public void setEquipment3Price(Double equipment3Price) {
        this.equipment3Price = equipment3Price;
    }

    public Equipment() {
    }

    public Equipment(String equipment1Name, Integer equipment1Quantity, Double equipment1Price,
     String equipment2Name, Integer equipment2Quantity, Double equipment2Price, String equipment3Name, Integer equipment3Quantity, Double equipment3Price ){
    this.equipment1Name = equipment1Name;
        this.equipment1Quantity = equipment1Quantity;
        this.equipment1Price = equipment1Price;
        this.equipment2Name = equipment2Name;
        this.equipment2Quantity = equipment2Quantity;
        this.equipment2Price = equipment2Price;
        this.equipment3Name = equipment3Name;
        this.equipment3Quantity = equipment3Quantity;
        this.equipment3Price = equipment3Price;
    }
}