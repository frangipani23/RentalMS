package com.Project.RentalMS;

import java.util.List;

//import com.Project.RentalMS.model.Equipment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EquipmentRepository extends JpaRepository<Equipment, Long> {
    // Custom query methods (if needed)

       // Find Equipment by Name
    List<Equipment> findByName(String name);

    // Find Equipment by BusinessUser
    List<Equipment> findByBusinessUser(BusinessUser businessUser);
}
