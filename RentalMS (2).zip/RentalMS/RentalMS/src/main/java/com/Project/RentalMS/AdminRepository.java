package com.Project.RentalMS;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AdminRepository extends JpaRepository<Admin, Long> {
    // Find by Email
    Optional<Admin> findByEmail(String email);

    // Other custom query methods if needed
}
