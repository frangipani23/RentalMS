package com.Project.RentalMS;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class AdminService {

    private final CustomerRepository customerRepository;
    private final BusinessUserRepository businessUserRepository;
    private final EquipmentRepository equipmentRepository;
    private final BookingRepository bookingRepository;

    public AdminService(CustomerRepository customerRepository,
                        BusinessUserRepository businessUserRepository,
                        EquipmentRepository equipmentRepository,
                        BookingRepository bookingRepository) {
        this.customerRepository = customerRepository;
        this.businessUserRepository = businessUserRepository;
        this.equipmentRepository = equipmentRepository;
        this.bookingRepository = bookingRepository;
    }

    // Customer Operations
    @Transactional
    public Customer createOrUpdateCustomer(Customer customer) {
        return customerRepository.save(customer);
    }

    public Optional<Customer> findCustomerById(Long id) {
        return customerRepository.findById(id);
    }

    public List<Customer> findAllCustomers() {
        return customerRepository.findAll();
    }

    public void deleteCustomer(Long id) {
        customerRepository.deleteById(id);
    }

    // BusinessUser Operations
    @Transactional
    public BusinessUser createOrUpdateBusinessUser(BusinessUser businessUser) {
        return businessUserRepository.save(businessUser);
    }

    public Optional<BusinessUser> findBusinessUserById(Long id) {
        return businessUserRepository.findById(id);
    }

    public List<BusinessUser> findAllBusinessUsers() {
        return businessUserRepository.findAll();
    }

    public void deleteBusinessUser(Long id) {
        businessUserRepository.deleteById(id);
    }

    // Equipment Operations
    @Transactional
    public Equipment createOrUpdateEquipment(Equipment equipment) {
        return equipmentRepository.save(equipment);
    }

    public Optional<Equipment> findEquipmentById(Long id) {
        return equipmentRepository.findById(id);
    }

    public List<Equipment> findAllEquipment() {
        return equipmentRepository.findAll();
    }

    public void deleteEquipment(Long id) {
        equipmentRepository.deleteById(id);
    }

    // Booking Operations
    @Transactional
    public Booking createOrUpdateBooking(Booking booking) {
        return bookingRepository.save(booking);
    }

    public Optional<Booking> findBookingById(Long id) {
        return bookingRepository.findById(id);
    }

    public List<Booking> findAllBookings() {
        return bookingRepository.findAll();
    }

    public void deleteBooking(Long id) {
        bookingRepository.deleteById(id);
    }

    // Additional methods for more complex operations can be added here
}
